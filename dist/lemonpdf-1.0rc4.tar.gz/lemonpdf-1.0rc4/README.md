# pdfurls

### Python3 library to get urls from PDF files.


### Install

    pip install pdfurls

### Quickstart


### Command line interface use (CLI)

    pdfurls file.pdf

#### save file

    pdfurls file.pdf --output  urls.txt --save